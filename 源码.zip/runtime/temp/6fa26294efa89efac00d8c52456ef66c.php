<?php /*a:1:{s:69:"/www/wwwroot/42.193.184.147/application/seller/view/login/mobile.html";i:1630552330;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="#" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>多商户客服登录</title>
    <link type="text/css" rel="styleSheet"  href="/static/seller/css/login.css" />
    <script type="text/javascript" src="/static/common/js/jquery.min.js"></script>
    <script type="text/javascript" src="/static/layui/layui.js"></script>
</head>
<body>
<div id="bg">
    <div style="height: 300px;width: 300px;background: #fff;border: 1px solid #eee;margin: 0 auto;top:20%;position: relative;text-align: center;line-height: 300px">
        <h3>商户后台请通过pc登录</h3>
    </div>
</div>

</body>
</html>