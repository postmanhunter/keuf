<?php /*a:1:{s:67:"/www/wwwroot/42.193.184.147/application/index/view/index/price.html";i:1630552330;}*/ ?>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="baidu-site-verification" content="LuFuQIGb35">
    <link rel=" hortcut icon" href="/favicon.ico" mce_href="/favicon.ico " type="image/x-icon">
    <link rel="stylesheet" href="/static/index/css/common-fdd194bb81.css">
    <meta name="format-detection " content="telephone=no ">
    <title>在线客服系统_网上客服系统_全渠道智能客服|AI智能客服【官网】</title>
    <meta name="keywords" content="网上客服系统,在线客服系统,智能客服,云客服系统,在线客服平台,IM客服软件,多渠道统一智能客服,全渠道客服系统">
    <meta name="description"
          content="AI智能在线客服系统,支持网页、微信、微博、APP、邮件等全渠道覆盖接入。主动营销服务：专注线上转化。数据报表:种类繁多，细致全面，拥有300多种，为量化客服管理提供支持。30万+家企业用户正在使用AI智能客服提供的在线客服系统、智能客服、云客服系统、在线客服平台、IM客服软件、云客服平台、全渠道客服系统，AI智能客服为企业在线客服团队用户提速增效、优化服务体验。">
    <link rel="stylesheet" href="/static/index/css/manual-8f852e8f11.css">
    <style>
        .detail-item {
            color: #545d69;
            min-height: 590px;
            width: 960px;
            margin: auto;
            padding: 90px 0;
            box-sizing: border-box;
            background-color: #fff;
        }
        .detail-item .paas-integrate {
            display: flex;
            height: 450px
        }
        .detail-item .paas-integrate .paas-integrate-item {
            width: 205px;
            position: relative;
            background-repeat: no-repeat;
            background-position: center;
            color: #fff
        }
        .detail-item .paas-integrate .paas-integrate-item .mask {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            top: 0;
        }
        .detail-item .paas-integrate .paas-integrate-item .integrate-item-icon {
            width: 70px;
            height: 60px;
            position: absolute;
            top: 130px;
            left: 50%;
            margin-left: -35px
        }
        .detail-item .paas-integrate .paas-integrate-item .integrate-item-title {
            position: absolute;
            top: 198px;
            left: 50%;
            transform: translateX(-50%)
        }
        .detail-item .paas-integrate .paas-integrate-item .integrate-item-title .title {
            font-size: 30px;
            font-weight: 700
        }
        .detail-item .paas-integrate .paas-integrate-item .integrate-item-title .bottom-line {
            width: 40px;
            height: 3px;
            margin: 0 auto;
            background-color: #FFFFFF;
        }
        .detail-item .paas-integrate .paas-integrate-item .integrate-item-text {
            position: absolute;
            top: 265px;
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            font-size: 18px
        }
        .detail-item .paas-integrate .paas-integrate-item .paas-integrate-list {
            display: none;
            position: absolute;
            top: 250px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 14px
        }
        .detail-item .paas-integrate .paas-integrate-item .paas-integrate-list li {
            line-height: 24px
        }
        .detail-item .paas-integrate .paas-integrate-item .paas-integrate-list li:before {
            content: " ";
            display: inline-block;
            vertical-align: middle;
            height: 4px;
            width: 4px;
            border-radius: 50%;
            margin-right: 5px;
            background-color: #fff
        }
        .detail-item .paas-integrate .paas-integrate-item.active {
            flex: 1
        }
        .detail-item .paas-integrate .paas-integrate-item.active .integrate-item-icon {
            top: 72px
        }
        .detail-item .paas-integrate .paas-integrate-item.active .integrate-item-title {
            top: 140px
        }
        .detail-item .paas-integrate .paas-integrate-item.active .integrate-item-text {
            top: 210px
        }
        .detail-item .paas-integrate .paas-integrate-item.active .paas-integrate-list {
            display: block
        }
        .detail-item .paas-integrate .paas-integrate-item.active.paas {
            background: #F6706C
        }
        .detail-item .paas-integrate .paas-integrate-item.active.p-and-s {
            background: #5751BB
        }
        .detail-item .paas-integrate .paas-integrate-item.active.saas {
            background: #4DBDEC
        }
        .detail-item .paas-integrate .paas-integrate-item.paas {
            background: #F6706C
        }
        .detail-item .paas-integrate .paas-integrate-item.p-and-s {
            background: #5751BB
        }
        .detail-item .paas-integrate .paas-integrate-item.saas {
            background: #4DBDEC
        }
    </style>
</head>
<body>
<div class="spec js-top-nav-outer">
    <div class="zc-navigation">
        <div class="zc-navigation-outer clearfix">
            <div class="company-logo">
                <a href="#"></a>
            </div>
            <div class="zc-navigation-button clearfix">
                <div class="buttons-outer">
                    <?php if(empty(session('seller_user_name'))): ?>
                    <div class="cover">
                        <a class="top-btn top-btn-login btn" style="position: relative" href="/seller/login/index">登录
                        </a>
                    </div>
                    <div class="cover">
                        <a class="top-btn top-btn-register btn btn-register" style="position: relative"
                           href="/seller/login/reg">免费试用
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="cover">
                        <a class="top-btn top-btn-register btn btn-register" style="position: relative;padding: 0 10px"
                           href="/seller/index">进入工作台
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="zc-navigation-menu">
                <ul class="clearfix">
                    <li class="js-top-list"><a href="/">首页</a></li>
                    <li class="js-top-list"><a href="/">客服优势</a></li>
                    <li class="js-top-list"><a href="/">AI智能</a></li>
                    <li class="js-top-list"><a href="/">数据报表</a></li>
                    <li class="js-top-list"><a href="/">技术保障</a></li>
                    <li class="js-top-list"><a href="/">功能简介</a></li>
                    <li class="js-top-list"><a href="/index/index/price">套餐价格</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="banner-outer" id="index_1">
    <div class="banner-inner"><h1>全渠道智能在线客服<br>统一管理，智能服务</h1>
        <div class="text">提升在线客服效率，专注线上转化</div>
        <div class="buttons">
            <a href="/seller/login/reg" class="btn">免费试用<?php echo config('seller.default_reg_day'); ?>天</a>
        </div>
    </div>
</div>
<div class="detail-item" style="position:relative;">
    <div class="paas-integrate">
        <div class="paas-integrate-item paas">
            <div class="integrate-item-title">
                <div class="title">轻奢版</div>
                <div class="bottom-line"></div>
            </div>
            <div class="integrate-item-text">108元/月</div>
            <div class="paas-integrate-list">
                <ul>
                    <li>不限制功能</li>
                    <li>全渠道接入</li>
                    <li>3坐席客服</li>
                </ul>
            </div>
        </div>
        <div class="paas-integrate-item p-and-s active">
            <div class="integrate-item-title">
                <div class="title">尊享版</div>
                <div class="bottom-line"></div>
            </div>
            <div class="integrate-item-text">988元/年</div>
            <div class="paas-integrate-list">
                <ul>
                    <li>不限制功能</li>
                    <li>全渠道接入</li>
                    <li>20坐席客服</li>
                    <li>7×24技术支持</li>
                </ul>
            </div>
        </div>
        <div class="paas-integrate-item saas">
            <div class="integrate-item-title">
                <div class="title">旗舰版</div>
                <div class="bottom-line"></div>
            </div>
            <div class="integrate-item-text">1888元/年</div>
            <div class="paas-integrate-list">
                <ul>
                    <li>不限制功能</li>
                    <li>全渠道接入</li>
                    <li>无限坐席</li>
                    <li>7×24技术支持</li>
                    <li>专属客服经理</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="seperator-line"></div>
    <div class="href-wrap">
        <a href="/seller/login/reg" target="_blank" class="one">免费体验</a>
    </div>
</div>
<div class="common-summary" style="color:#939393;">
    <div>
        <span id="text4">Copyright © 2015-<?php echo date('Y'); ?> AI智能客服 版权所有</span>
    </div>

</div>
<script src="/static/index/js/jquery-8b229831f4.min.js"></script>
<script>
    $(window).scroll(function () {
        if ($(window).scrollTop() > 0) {
            $(".zc-navigation").addClass('active');
        }
        if ($(window).scrollTop() < 10) {
            $(".zc-navigation").removeClass('active');
        }
    });

    $(".paas-integrate-item").mouseover(function(){
        $(".paas-integrate-item").removeClass("active");
        $(this).addClass('active');
    });
</script>
<script src="/index/index/chatBoxJs/u/5c6cbcb7d55ca"></script>
<script>ServiceChat.init();</script>
</body>
</html>