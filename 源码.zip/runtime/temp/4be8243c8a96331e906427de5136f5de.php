<?php /*a:1:{s:67:"/www/wwwroot/42.193.184.147/application/seller/view/index/home.html";i:1630552330;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>多商户客服首页面板</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/style/admin.css" media="all">
</head>
<body>

<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-sm6 layui-col-md3">
            <div class="layui-card">
                <div class="layui-card-header">
                    累计接待量
                </div>
                <div class="layui-card-body layuiadmin-card-list">
                    <p class="layuiadmin-big-font"><?php echo htmlentities($total_num); ?></p>
                </div>
            </div>
        </div>
        <div class="layui-col-sm6 layui-col-md3">
            <div class="layui-card">
                <div class="layui-card-header">
                    今日接待量
                </div>
                <div class="layui-card-body layuiadmin-card-list">
                    <p class="layuiadmin-big-font"><?php echo htmlentities($today_num); ?></p>
                </div>
            </div>
        </div>
        <div class="layui-col-sm6 layui-col-md3">
            <div class="layui-card">
                <div class="layui-card-header">
                    当前在线客服
                </div>
                <div class="layui-card-body layuiadmin-card-list">
                    <p class="layuiadmin-big-font"><?php echo htmlentities($online_kefu); ?></p>
                </div>
            </div>
        </div>
        <div class="layui-col-sm6 layui-col-md3">
            <div class="layui-card">
                <div class="layui-card-header">
                    当前在线未咨询访客
                </div>
                <div class="layui-card-body layuiadmin-card-list">

                    <p class="layuiadmin-big-font"><?php echo htmlentities($customer_num); ?></p>
                </div>
            </div>
        </div>

        <div class="layui-col-sm12">
            <div class="layui-row layui-col-space15">
                <div class="layui-col-sm8">
                    <div class="layui-card">
                        <div class="layui-card-header">在线客服详情</div>
                        <div class="layui-card-body">
                            <table class="layui-table layuiadmin-page-table" lay-skin="line">
                                <thead>
                                <tr>
                                    <th>用户名</th>
                                    <th>最后登录时间</th>
                                    <th>状态</th>
                                    <th>服务人数</th>
                                    <th>累计服务人数</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php if(!empty($kefu)): if(is_array($kefu) || $kefu instanceof \think\Collection || $kefu instanceof \think\Paginator): if( count($kefu)==0 ) : echo "" ;else: foreach($kefu as $key=>$vo): ?>
                                <tr>
                                    <td><span class="first"><?php echo htmlentities($vo['kefu_name']); ?></span></td>
                                    <td><i class="layui-icon layui-icon-log"> <?php echo htmlentities($vo['last_login_time']); ?></i></td>
                                    <td><span><?php if($vo['online_status'] == 1): ?>在线<?php else: ?>忙碌<?php endif; ?></span></td>
                                    <td><?php echo htmlentities($vo['service_num']); ?></td>
                                    <td><?php echo htmlentities($vo['total_service_num']); ?></td>
                                </tr>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="layui-col-sm4">
                    <div class="layui-card">
                        <div class="layui-card-header">使用有效期</div>
                        <div class="layui-card-body">
                            <table class="layui-table layuiadmin-page-table" lay-skin="line">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>日期</th>
                                    <th>天数</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>有效期至</td>
                                    <td><?php echo htmlentities($seller['valid_time']); ?></td>
                                    <td><?php echo getValidDays($seller['valid_time']); ?></td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="layui-col-sm12">
            <div class="layui-card">
                <div class="layui-card-header">
                    最近15天接待情况
                </div>
                <div class="layui-card-body">
                    <div class="layui-row">
                        <div class="layui-col-sm812">
                            <div carousel-item id="LAY-index-pagetwo" style="width: 100%;height: 400px">
                                <div><i class="layui-icon layui-icon-loading1 layadmin-loading"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script src="/static/admin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/admin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(["index", "echarts"], function () {

        var myChart = echarts.init(document.getElementById('LAY-index-pagetwo'), layui.echartsTheme);

        var option = {
            tooltip: {
                trigger: 'axis'
            },
            xAxis: {
                type: 'category',
                data: <?php echo $fifteenDays; ?>
            },
            yAxis: {
                type: 'value'
            },
            series: [{
                name: '接待人数',
                data: <?php echo $fifteenNum; ?>,
                type: 'line',
                smooth: true
            }]
        };

        myChart.setOption(option);
    });
</script>
</body>
</html>