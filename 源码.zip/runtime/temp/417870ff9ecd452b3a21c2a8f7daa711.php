<?php /*a:1:{s:71:"/www/wwwroot/42.193.184.147/application/seller/view/robot/question.html";i:1630552330;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>未知问题列表</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/style/admin.css" media="all">
</head>
<body>

<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-card-body">
            <table id="LAY-user-table" lay-filter="LAY-user-table"></table>
            <script type="text/html" id="table-seller-admin">
                <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><i class="layui-icon layui-icon-delete"></i>删除</a>
            </script>
        </div>
    </div>
</div>

<script src="/static/admin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/admin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use(['index'], function(){
        var $ = layui.$;

        var active = {

            add: function(){

            }
        };

        $('.layui-btn.layuiadmin-btn-admin').on('click', function(){
            var type = $(this).data('type');
            active[type] ? active[type].call(this) : '';
        });
    });

    renderTable();
    // 渲染表格
    function renderTable() {

        layui.use(['table', 'form'], function () {
            var $ = layui.$
                ,form = layui.form
                ,table = layui.table;

            table.render({
                elem: "#LAY-user-table",
                url: "/seller/robot/question",
                cols: [
                    [{
                        field: "question",
                        title: "问题"
                    }, {
                        field: "customer_name",
                        title: "提问人"
                    }, {
                        field: "create_time",
                        title: "提问时间"
                    }, {
                        title: "操作",
                        align: "center",
                        fixed: "right",
                        toolbar: "#table-seller-admin"
                    }]
                ],
                page: !0,
                limit: 20,
                height: "full-220",
                text: {
                    none: '暂无相关数据'
                }
            });

            table.on("tool(LAY-user-table)",
                function(e) {
                    if ("del" === e.event) {

                        layer.confirm('您确定要删除该问答？', {
                            title: '友情提示',
                            icon: 3,
                            btn: ['是的', '再想想']
                        }, function(){

                            $.getJSON("/seller/robot/delQuestion/id/" + e.data.question_id, function (res) {
                                if(0 == res.code) {
                                    layer.msg(res.msg);
                                    setTimeout(function () {
                                        renderTable();
                                    }, 300);
                                } else {
                                    layer.msg(res.msg);
                                }
                            });

                        }, function(){

                        });
                    } else if ("edit" === e.event) {

                    }
                });

            // 监听搜索
            form.on('submit(LAY-user-front-search)', function(data){
                var field = data.field;

                // 执行重载
                table.reload('LAY-user-table', {
                    where: field
                });
            });
        });
    }
</script>
</body>
</html>
