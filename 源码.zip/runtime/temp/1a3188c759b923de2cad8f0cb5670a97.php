<?php /*a:1:{s:67:"/www/wwwroot/42.193.184.147/application/index/view/index/index.html";i:1641535518;}*/ ?>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="baidu-site-verification" content="LuFuQIGb35">
    <link rel=" hortcut icon" href="/favicon.ico" mce_href="/favicon.ico " type="image/x-icon">
    <link rel="stylesheet" href="/static/index/css/common-fdd194bb81.css">
    <meta name="format-detection " content="telephone=no ">
    <title>在线客服系统_网上客服系统_全渠道智能客服|AI智能客服【官网】</title>
    <meta name="keywords" content="网上客服系统,在线客服系统,智能客服,云客服系统,在线客服平台,IM客服软件,多渠道统一智能客服,全渠道客服系统">
    <meta name="description" content="AI智能在线客服系统,支持网页、微信、微博、APP、邮件等全渠道覆盖接入。主动营销服务：专注线上转化。数据报表:种类繁多，细致全面，拥有300多种，为量化客服管理提供支持。30万+家企业用户正在使用AI智能客服提供的在线客服系统、智能客服、云客服系统、在线客服平台、IM客服软件、云客服平台、全渠道客服系统，AI智能客服为企业在线客服团队用户提速增效、优化服务体验。">
    <link rel="stylesheet" href="/static/index/css/manual-8f852e8f11.css">
    <style>
        .home-reputation {
            box-sizing: border-box;
            position: fixed;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 960px;
            height: 70px;
            padding: 15px 0 15px 45px;
            background-color: #f9f5e5;
            font-size: 13px;
            color: #83796e;
            z-index: 20
        }
        .home-reputation.hide {
            display: none
        }
        .home-reputation .close {
            position: absolute;
            right: 10px;
            top: 5px;
            width: 13px;
            height: 13px;
            cursor: pointer
        }
        .home-reputation .content {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap
        }
        .home-reputation .content > div {
            position: relative;
            display: flex;
            width: 100%;
            height: 14px
        }
        .home-reputation .content > div:first-of-type {
            margin-bottom: 5px
        }
        .home-reputation .content img {
            position: absolute;
            width: 13px;
            height: 13px;
            top: 3px;
            left: -18px;
            margin-right: 8px
        }
    </style>
</head>
<body>
<div class="spec js-top-nav-outer">
    <div class="zc-navigation">
        <div class="zc-navigation-outer clearfix">
            <div class="company-logo">
                <a href="#"></a>
            </div>
            <div class="zc-navigation-button clearfix">
                <div class="buttons-outer">
                    <?php if(empty(session('seller_user_name'))): ?>
                    <div class="cover">
                        <a class="top-btn top-btn-login btn" style="position: relative" href="/seller/login/index">登录
                        </a>
                    </div>
                    <div class="cover">
                        <a class="top-btn top-btn-register btn btn-register" style="position: relative" href="/seller/login/reg">免费试用
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="cover">
                        <a class="top-btn top-btn-register btn btn-register" style="position: relative;padding: 0 10px" href="/seller/index">进入工作台
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="zc-navigation-menu">
                <ul class="clearfix">
                    <li class="js-top-list"><a href="#index_1">首页</a></li>
                    <li class="js-top-list"><a href="#index_2">客服优势</a></li>
                    <li class="js-top-list"><a href="#index_3">AI智能</a></li>
                    <li class="js-top-list"><a href="#index_4">数据报表</a></li>
                    <li class="js-top-list"><a href="#index_5">技术保障</a></li>
                    <li class="js-top-list"><a href="#index_6">功能简介</a></li>
                    <li class="js-top-list"><a href="/index/index/price">套餐价格</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="banner-outer" id="index_1">
    <div class="banner-inner"><h1>全渠道智能在线客服<br>统一管理，智能服务</h1>
        <div class="text">提升在线客服效率，专注线上转化</div>
        <div class="buttons">
            <a href="/seller/login/reg" class="btn">免费试用<?php echo config('seller.default_reg_day'); ?>天</a>
        </div>
    </div>
</div>
<div class="detail-item" id="index_2">
    <h2>把握客户咨询，商机转化率提升30%</h2>
    <div class="detail-info expand" expand="">
        <div class="ul-outer"><h5>全渠道覆盖</h5><h6 class="green">接待响应一站式</h6>
            <ul>
                <li>桌面网站</li>
                <li>App</li>
                <li>微信</li>
                <li>短信</li>
            </ul>
            <ul>
                <li>移动网站</li>
                <li>邮件</li>
                <li>微博</li>
            </ul>
        </div>
        <div class="image-outer"></div>
    </div>
    <div class="detail-info expand" expand="">
        <div class="ul-outer right"><h5 class="green">精准用户画像</h5><h6>决策更有智慧</h6>
            <ul>
                <li>浏览轨迹</li>
                <li>客户信息</li>
                <li>情感分析</li>
            </ul>
            <ul>
                <li>舆情分析</li>
                <li>历史聊天记录</li>
                <li class="spec">······</li>
            </ul>
        </div>
        <div class="image-outer second"></div>
    </div>
    <div class="detail-info expand" expand>
        <div class="ul-outer" style="margin-top:55px"><h5>主动营销服务</h5><h6>专注<span class="green">线上转化</span></h6>
            <ul style="width:100%">
                <li>自动弹窗邀请</li>
                <li>客服主动邀请会话</li>
                <li>常见问题引导</li>
                <li>热点推荐</li>
                <li class="spec">······</li>
            </ul>
        </div>
        <div class="image-outer third"></div>
    </div>
    <div class="href-wrap">
        <a href="/seller/login/reg" target="_blank" class="one">立即注册，亲自体验产品</a>
    </div>
</div>
<div class="detail-item green" id="index_3">
    <h2>高效优质服务，成单率提升50%</h2>
    <div class="list-outer">
        <div class="list-item">
            <div class="logo" data-name="phone"></div>
            <h4>四种接待方式</h4><h4>匹配不同业务接待场景</h4>
            <ul>
                <li>机器人客服优先</li>
                <li>人工客服优先</li>
                <li>仅机器人客服</li>
                <li>仅人工客服</li>
            </ul>
        </div>
        <div class="list-item">
            <div class="logo" data-name="microphone"></div>
            <h4>声情并茂的富媒体沟通</h4><h4>沟通效率翻倍</h4>
            <ul>
                <li>图片/文字</li>
                <li>语音/视频</li>
                <li>表情</li>
                <li>商品链接</li>
                <li>文件传输</li>
            </ul>
        </div>
        <div class="list-item">
            <div class="logo" data-name="robot"></div>
            <h4>机器人客服接待／辅助人工</h4><h4>客户服务秒级响应</h4>
            <ul>
                <li>机器人客服快速接待</li>
                <li>机器人客服辅助人工</li>
                <li>快速检索知识库</li>
                <li>智能监控</li>
            </ul>
        </div>
    </div>
    <div class="href-wrap sky-blue">
        <a href="/seller/login/reg" target="_blank" class="one">立即注册，亲自体验产品</a>
    </div>
</div>
<div class="detail-item" id="index_4">
    <h2>强大统计报表，业务数据完美升华</h2>
    <div class="detail-info expand" expand="">
        <div class="ul-outer long"><h5 class="green">服务数据统计</h5><h6 class="">为量化客服管理提供支持</h6>
            <div class="text">提供人工客服坐席工作量／服务质量／满意度等指标，为数据化管理提供支持和保障。</div>
        </div>
        <div class="image-outer forth"></div>
    </div>
    <div class="detail-info expand" expand="" style="margin-top:180px">
        <div class="ul-outer right long"><h5 class="green">客户全方位洞察，</h5><h6>让服务更契合客户<br>所需所想</h6>
            <ul style="width:100%">
                <li>客户来源／关键词／着陆页/浏览轨迹等客户行为完整统计， 让营销效果有迹可循。</li>
                <li>客户会话／消息记录等，让你了解与客户的每一次沟通。</li>
            </ul>
        </div>
        <div class="image-outer fifth"></div>
    </div>
    <div class="href-wrap">
        <a href="/seller/login/reg" target="_blank" class="one">立即注册，亲自体验产品</a>
    </div>
</div>
<div class="detail-item gray" id="index_5">
    <h2>多重技术保障，保证稳定不丢消息</h2>
    <div class="ensure-banner-outer expand" expand="">
        <div class="logo-outer js-logo-outer active">
            <div class="logo-inner">
                <div class="logo-tips">更适合移动时代的<br>复杂网络环境判断</div>
            </div>
        </div>
        <div class="logo-outer js-logo-outer">
            <div class="logo-inner">
                <div class="logo-tips">两地三中心备灾方案</div>
            </div>
        </div>
        <div class="logo-outer js-logo-outer">
            <div class="logo-inner right">
                <div class="logo-tips right">大数据<br>集群部署</div>
            </div>
        </div>
        <div class="logo-outer js-logo-outer">
            <div class="logo-inner">
                <div class="logo-tips">动态DNS持续重连<br>直至到达</div>
            </div>
        </div>
        <div class="logo-outer js-logo-outer">
            <div class="logo-inner right">
                <div class="logo-tips right">全面的SLA保障体系<br>及赔付方案</div>
            </div>
        </div>
        <div class="logo-outer spec js-logo-outer">
            <div class="logo-inner right">
                <div class="logo-tips right">长连接技术</div>
            </div>
        </div>
    </div>
    <div class="href-wrap">
        <a href="/seller/login/reg" target="_blank" class="one">立即注册，亲自体验产品</a>
    </div>
</div>
<div class="detail-item" style="position:relative;" id="index_6">
    <h2>更多功能列表</h2>
    <div class="grid-outer">
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">多渠道接入</div>
            <div class="desc">AI智能客服支持桌面网站、移动网站、App、微信、微博、短信等多种渠道接入，客服可以在一个后台接待所有渠道来访的用户。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">多种接待方式</div>
            <div class="desc">企业可根据自身的业务场景来决定采用人工客服还是机器人客服的方式进行接待，也可以配置为人工客服优先接待或智能机器人客服优先接待。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">客服技能组分类</div>
            <div class="desc">企业可根据自身的业务需要配置不同的技能组，并配置相关技能组下的客服人员，访客可以根据自身的业务咨询需求，选择更有针对性解决的客服组进行服务。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">富媒体沟通</div>
            <div class="desc">除了纯文字，客服还可以通过表情、图片、富文本、超链接等多种方式回答问题，让用户和客服之间的沟通不再单一。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">会话自动应答</div>
            <div class="desc">客户可对一些特定的场景，例如客服不在线、超时无响应等场景，进行一些自动应答的偏好设置。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">自动弹框邀请</div>
            <div class="desc">用户浏览网站的过程中，系统可自动弹窗邀请用户加入咨询。对于有咨询意向的用户而言，减少了其发起咨询的操作，大幅提升用户体验。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">客服主动邀请会话</div>
            <div class="desc">客服可以选择对正在排队或正在浏览网站的用户发起主动会话邀请，主动拉近用户距离，并进一步促进了订单的转化。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">聊天信息同步</div>
            <div class="desc">人工客服和用户建立新的会话后，可看到用户曾经和其他人工客服或机器人客服的聊天记录，帮助客服更好地定位用户问题，减少信息断层。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">用户身份画像</div>
            <div class="desc">客服在接待用户时可看到用户的基础信息，包括昵称、联系方式、订单记录等。若企业有需要，也可以把自己企业的CRM系统信息对接至AI智能客服系统。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">用户来源</div>
            <div class="desc">可根据客户来源渠道、搜索词、受访页面、着陆页面等多个维度查询访客的相关来源信息，更好帮助企业分析线索的投放情况。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">用户浏览轨迹</div>
            <div class="desc">客服在接待用户时可查看用户在各个页面的访问轨迹，从而更好地了解到用户的真实需求，减少沟通成本的同时促进订单转化提升。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">用户访问分析</div>
            <div class="desc">管理者可通过会话和访客两个维度查询各个渠道的用户来访数据，并可以选择不同参数来自定义查询报表和导出报表。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">智能质检</div>
            <div class="desc">企业可对客服的日常工作进行质检，不仅如此，还可以为质检项目配置质检评分标准以及质检标签。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">客服工作量分析</div>
            <div class="desc">企业管理员不仅可以对客服的整体工作情况进行直观地查看以及统计分析，而且可以针对性地查看具体单个客服的接待情况。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">会话记录</div>
            <div class="desc">管理员可以通过不同条件自定义查询人工客服或机器人客服的接待情况，查看完整会话记录。据此，企业可以更好地进行服务质量监控。</div>
        </div>
        <div class="grid-column">
            <div class="logo-outer"></div>
            <div class="text">客户满意度评价</div>
            <div class="desc">访客不仅可以在会话结束后对人工客服的工作进行满意度评价，而且可以在评价时选择相应的评价标签。</div>
        </div>
    </div>
    <div class="seperator-line"></div>
    <div class="href-wrap">
        <a href="/seller/login/reg" target="_blank" class="one">立即注册，亲自体验产品</a>
    </div>
</div>
<div class="common-summary" style="color:#939393;">


</div>
<div class="home-reputation">
    <div class="content">
        <div>
            <img src="/static/index/images/warning-a47e094a16.png" alt="">
            <span>使用AI智能客服产品期间，不得危害国家安全、泄露国家秘密，不得侵犯国家社会集体和公民的合法权益。</span>
        </div>
        <div>AI智能客服产品禁止用于含有木马、病毒、色情、赌博、诈骗等违法违规业务。一经发现，AI智能客服有权立即停止服务，并协助相关行政执法机关进行清查。</div>
    </div>
    <img src="/static/index/images/close-20dcd1ad6c.png" alt="" class="close" id="homeReputationClose">
</div>
<script src="/static/index/js/jquery-8b229831f4.min.js"></script>
<script>
    $(window).scroll(function(){
        if($(window).scrollTop() > 0){
            $(".zc-navigation").addClass('active');
        }
        if($(window).scrollTop() < 10){
            $(".zc-navigation").removeClass('active');
        }
    });

    $(".js-logo-outer").mouseover(function(){
        $(".js-logo-outer").removeClass("active");
        $(this).addClass('active');
    });
    // 声名部分 关闭按钮绑定事件
    $('#homeReputationClose').on('click', function (ev) {
        ev.stopPropagation();
        $('.home-reputation').addClass('hide');
    });
</script>
<script src="/index/index/chatBoxJs/u/5c6cbcb7d55ca"></script>
<script>ServiceChat.init();</script>
</body>
</html>