<?php /*a:1:{s:68:"/www/wwwroot/42.193.184.147/application/seller/view/login/index.html";i:1641491191;}*/ ?>

<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="all"/>
    <meta name="Author" content="Cc客服,云客服官方网站" />
    <meta name="keywords" content="Cc客服,云客服客服系统,客服软件,在线客服,在线客服软件,智能客服系统,全渠道客服系统,呼叫中心,客服解决方案" />
    <meta name="description" contenct="云客服智能客服系统WEB工作平台登录地址，云客服是新一代全渠道智能客服系统，帮助企业提升客户满意度，降低服务成本。" />
    <title>Cc客服登录_客服管理系统登录</title>
    
    <link rel="stylesheet" href="/static/seller/css/bw8_login.css?v=a8f579fe" />
    <style type="text/css">
        .bw8_login {
            width: 100%;
            height: 100%;
            background: url('/static/seller/images/loginbg.1a76cb7f.jpg?v=aff73687') center center no-repeat;
            background-size: cover;
            position: relative;
        }

    </style>
    <!--i18n i10n lib-->
<script src="http://42.193.184.147/index/index/chatBoxJs/u/5c6cbcb7d55ca"></script>    
<script type="text/javascript" src="/static/seller/js/gettext.js?v=ac729623"></script>

<script type="text/javascript" src="/static/seller/js/jquery-1.8.3.js?v=a2073df8" ></script>
    <link rel="stylesheet" type="text/css" href="/static/seller/css/reset.css?v=a1f22a14" />
    </head>
<body>
    
    <div class="bw8_login">
        <div class="bw8_header_logo">
      
        </div>
        <div class="bw8_login_content">
            <div class="login_title" style="color: black;">登录Cc客服Web工作台</div>
            <div class="login_content">
                <div class='login_img'>
                    <a href=""  target="_blank" style='display:block;'>
                        <img src="/static/seller/images/website-landing-page_plan-eg-two.6571b079a8e2.png?v=a4d4cc99" alt="生态联盟峰会" style='width: 490px;height:360px;'>
                    </a>
                    
                </div>
            <div class='login_user'>
                
                
                <form action="post" style="padding:0px;margin:0px;">

                    <div class="bw8_input bw8_login_input">
                        <input type="text" id="u"value="" class="" placeholder="请输入账号">
                      
                    </div>
                    <div class="bw8_input bw8_pwd_input">
                        <input type="password" id="p"class="" value="" placeholder="请输入密码">
                    </div>
                    <div class="code_content">
                        <div class="p1">
                            
                            
     <input type="text" id="captcha-code"value="" class="" placeholder="请输入验证码"style="width: 145px; height: 35px; " STYLE="width: 145px; height: 35px; width: 145px; height: 35px; " />

     
                            
        <img src="<?php echo captcha_src(); ?>" class="dhn_fr" alt="captcha" onclick="changeCaptcha(this)" id="captcha" style="width:120px;height: 41px;/* position: absolute; */margin-top:-3px;right: 0;"/>


                            <div id="vsnDiv" class="dhn_fr" style="margin-top: 7px;"></div>
                            <p id="vsnErTip" class="tip"></p>
                        </div>
                        
                    </div>

                    <div class="bw8_login_btn">
                        <input type="button"  id="btn" value="登录" />
                    </div>

                    <div class="wx_login_btns">
                        <div class="wx_login_cut">或</div>
                 
                    </div>

                </FORM>


			  
                <div class="bw8_login_pwd_btn">
                   
                    <a class="dhn_fr" href="/seller/login/reg.html" target="_blank">免费注册试用</a>
                </div>
            </div>
            </div>
        </div>
</div>





<script>
    //微信登录
    $(function(){
        var $wxLogin = $('.bw8_login');

        var $wxScanType = $('#wxScanType');//1是oem，不展示微信扫码
        if($wxScanType.val()!='1'){
            $wxLogin.addClass('wx_login');
            $wxLogin.addClass('ad_show_wrap');//广告位
        }
        //顶部提示
        $('body').append('<div id="div_container" style="position: absolute;left:35%;top:0;z-index: 3000;"></div>');
        var showTip = new showErrorTip();
        var showMsg = function(msg,type){
            showTip.showError(msg,type);
        }

        var expireSeconds = 60*1000;
        var qrcodeTime = 0;//上次请求二维码的时间戳
        var qrcodeId; //
        var timer=null;
        var startCheck = false;//循环调用接口
        var checkCount = 0;//检查次数

        var $qrcodeImg = $('.wx_login_qrcode_img');

        var $loginForm = $("form[name='login']");//登录form
        var loginUrl = $loginForm.attr("action");

        var $loginContent = $('.bw8_login_content');
        var $wxLoginPopup = $('.wx_login_popup');

        var $wxLoginBtn = $('.wx_login_link');//微信登录按钮
        var $qrCodeMask = $('.wx_login_qrcode_img_mask');//过期的遮罩

        //获取url参数

        //添加加载的时候
        
        //显示二维码
        function showQrCode() {
            if(qrcodeExpire()){
                //已过期，重新获取
                // $qrcodeImg.hide();
                wxBindAjax(1);
            }else{
                qrCodeMask(false);
            }
        }


        //检查二维码是否过期
        function qrcodeExpire(){
            return new Date().getTime()-qrcodeTime> expireSeconds;
        }


        // /osp2016/agent/bindServiceWx.php  post请求    sid=客服id  type 1 二维码  2绑定 3 解绑
        function wxBindAjax(type){
            var obj = {
                type: type,
            };
            $.post("/osp2016/agent/bindServiceWx.php", obj,
                function(data){
                    if(data.code===200){
                        if(type===1){
                            $qrcodeImg.attr('src',data.data.url).show();
                            qrcodeId = data.data.id;
                            expireSeconds = (data.data.expire_seconds - 10)*1000;
                            qrcodeTime = new Date().getTime();
                            qrCodeMask(false);
                        }
                    }
                }, "json");
        }


        //检查微信扫描状态
        function checkWxStatus(start) {
            if(typeof start === "boolean"){
                startCheck = start;
            }
            if(start){
                checkCount = 0;
            }
            if(startCheck){
                checkCount++;
                var time = 3000;
                if(checkCount<40){
                    if(checkCount<30){
                        time = 2000;
                    }
                    setTimeout(function () {
                        if(qrcodeExpire()&&qrcodeTime!==0){
                            showQrCode();
                        }
                        getWxStatus();
                    },time);
                }else {
                    startCheck = false;
                    //提示二维码过期
                    qrCodeMask(true);
                }
            }
        }

        //显示隐藏过期遮罩

        //检查该微信账号是否绑定过账号
      
        //使用微信登录
        function wxLogin(openid,obj){
            formSubmit('post',loginUrl,obj);
        }

        /*
        *功能： 模拟form表单的提交
        *参数： URL 跳转地址 PARAMTERS 参数
        */
    })
</script>
<script type="text/javascript" src="/static/common/js/jquery.min.js"></script>
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script>if(window.top !== window.self){ window.top.location = window.location;}</script>
<script>
    document.onkeydown=function(event){
        var e = event || window.event || arguments.callee.caller.arguments[0];
        if(e && e.keyCode==13){ // enter 键
            doLogin();
        }
    };

    $(function(){
        $("#btn").click(function(){
            doLogin();
        });
    });

    function doLogin(){
        layui.use(['layer'], function(){
            var layer = layui.layer;
            layer.ready(function(){
                var user_name = $("#u").val();
                var password = $("#p").val();
                var captcha = $("#captcha-code").val();

                if('' == user_name){
                    layer.tips('请输入用户名', '#u');
                    return false;
                }

                if('' == password){
                    layer.tips('请输入密码', '#p');
                    return false;
                }

                if('' == captcha){
                    layer.tips('验证码不能为空', '#captcha-code');
                    return false;
                }

                var index = layer.load(0, {shade: false});
                $.post('/seller/login/doLogin', {
                    username: user_name,
                    password: password,
                    captcha: captcha
                }, function(res){
                    layer.close(index);
                    if(0 == res.code){
                        window.location.href = res.data;
                    }else{
                        $("#captcha").click();
                        return layer.msg(res.msg, {icon: 2, anim: 6});
                    }
                }, 'json');
            });
        });
    }

    function changeCaptcha(obj) {
        $(obj).attr('src', $(obj).attr('src') + '?t=' + Math.random());
    }
</script>
<script src="http://42.193.184.147/index/index/chatBoxJs/u/5c6cbcb7d55ca"></script>

<script>ServiceChat.init();</script>
</body>
</html>