<?php /*a:1:{s:69:"/www/wwwroot/42.193.184.147/application/index/view/index/cli_box.html";i:1630840716;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>在线客服</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1，minimum-scale=1, user-scalable=no">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/customer/css/ai_service.cli.v2.css">
    <link rel="stylesheet" href="/static/common/js/jqueryWeui/weui.min.css">
    <link rel="stylesheet" href="/static/common/js/jqueryWeui/jquery-weui.min.css">
    <link rel="stylesheet" href="/static/common/css/iconfont.css">
    <style>
        .chat-message{
            -webkit-touch-callout: all;
            -webkit-user-select: all;
            -moz-user-select: all;
            -ms-user-select: all;
            user-select: all;
        }
        .clearfloat .right .chat-message{
            background: <?php echo htmlentities($style['box_color']); ?>;
        }
        .clearfloat .right .chat-message:before {
            border-left: 10px solid <?php echo htmlentities($style['box_color']); ?>;;
        }
    </style>
</head>
<body <?php if($type == 2 && $os == 'p'): ?>style="background:#ffffff"<?php endif; ?>>
<div class="chat-container" id="app" <?php if($type == 2 && $os == 'p'): ?>style="position:relative;top: 50px;width: 768px;height:600px;margin:0 auto;box-shadow: 0 0 24px 0 rgb(15 66 76 / 25%); "<?php endif; ?>>
    <div class="layui-row chat-header" style="background: <?php echo htmlentities($style['box_color']); ?>">
        <div class="<?php if($type == 2 && $os == 'p'): ?>layui-col-xs1<?php else: ?>layui-col-xs2<?php endif; ?> chat-header-avatar">
            <?php if($type == 2 && $os == 'm'): ?><i class="layui-icon layui-icon-left chat-back" id="goBack"></i><?php endif; ?>
            <img src="/static/common/images/kefu.png" class="agent-avatar" <?php if($type == 2 && $os == 'm'): ?>style="left:40px"<?php endif; ?>/>
        </div>
        <div class="<?php if($type == 2 && $os == 'p'): ?>layui-col-xs10<?php else: ?>layui-col-xs9<?php endif; ?> chat-header-title" <?php if($type == 2 && $os == 'm'): ?>style="padding-left:30px"<?php endif; ?>>
            <?php if($robot_open == 1): ?><?php echo htmlentities($robot_title); else: ?>官方客服为您服务<?php endif; ?>
        </div>
        <?php if($type == 1): ?>
        <div class="layui-col-xs1 chat-header-tool" id="closeBtn">
            <i class="layui-icon layui-icon-down"></i>
        </div>
        <?php elseif($type == 2): ?>
        <div class="layui-col-xs1 chat-header-tool" id="operatorVoice">
            <span class="iconfont" style="font-size: 20px" id="openVoice">&#xe69f;</span>
            <span class="iconfont" style="font-size: 20px;display: none" id="closeVoice">&#xe69d;</span>
        </div>
        <?php endif; ?>
    </div>
    <div class="layui-row chat-body" <?php if($type == 2 && $os == 'p'): ?>style="width:70%"<?php endif; ?>>
        <div class="chat-box">

        </div>
    </div>
    <div class="layui-row chat-footer" <?php if($type == 2 && $os == 'p'): ?>style="width:70%;border-right:1px solid #eee"<?php endif; ?>>
        <div class="text-holder">
            <textarea id="textarea" placeholder="请输入内容" onblur="window.scroll(0, 0)"></textarea>
        </div>
        <div class="send-bar">
            <div class="tool-box">
                <i class="layui-icon layui-icon-face-smile" id="face"></i>
                <i class="layui-icon layui-icon-picture" id="image"></i>
                <i class="layui-icon" style="font-size: 20px;" id="file" title="文件">&#xe61d;</i>
                <!--<i class="layui-icon layui-icon-speaker" id="voice" title="语音"></i>-->
                <span class="staff-service">转人工</span>
            </div>
            <div class="send-btn-div">
                <input type="button" value="发送" class="send-input" id="sendBtn">
            </div>
        </div>
    </div>
    <?php if($type == 2 && $os == 'p'): ?>
    <div class="layui-row" style="height: 510px;width: 230px;float: right;background: #fff;margin-top: 62px;">
        <div class="layui-tab layui-tab-brief" style="height: 490px;overflow-y:auto">
            <ul class="layui-tab-title">
                <li class="layui-this">常见问题</li>
            </ul>
            <div class="layui-tab-content">
                <div class="layui-tab-item info-msg layui-show">
                    <?php if(is_array($question) || $question instanceof \think\Collection || $question instanceof \think\Paginator): if( count($question)==0 ) : echo "" ;else: foreach($question as $key=>$vo): ?>
                    <p><a href="javascript:;" onclick="autoAnswer(this)" data-id="<?php echo htmlentities($vo['question_id']); ?>" style="font-size: 14px"><?php echo htmlentities($vo['question']); ?></a></p>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<audio src="/static/voice/default.wav" style="display: none;" id="ai_service-index-audio"></audio>

<div id="praise_box" style="display: none;text-align: center;padding-top: 19%">
    <p>请您对我本次服务做出评价：</p>
    <div id="praise_star"></div>
</div>

<div class="layui-form" action="" style="display: none;" id="msg-box">
    <div class="layui-form-item" style="margin-top: 10px">
        <label class="layui-form-label">手机号</label>
        <div class="layui-input-block">
            <input type="text" name="phone" required  lay-verify="required" autocomplete="off" class="layui-input" style="width: 200px;" id="phone">
        </div>
    </div>
    <div class="layui-form-item">
        <div class="layui-input-block">
            <button class="layui-btn layui-btn-normal" id="sub-btn">提交咨询</button>
        </div>
    </div>
</div>

<script>

    var socketUrl = '<?php echo htmlentities($socket); ?>';
    var seller_id = '<?php echo htmlentities($seller_id); ?>';
    var seller = '<?php echo htmlentities($seller); ?>';
    var t = '<?php echo htmlentities($nowTime); ?>';
    var tk = '<?php echo htmlentities($token); ?>';
    var type = <?php echo htmlentities($type); ?>;
    var port = <?php echo htmlentities($port); ?>;
    var direct_kefu = '<?php echo htmlentities($direct_kefu); ?>';
    var robot_open = <?php echo htmlentities($robot_open); ?>;
    var robot_hello = '<?php echo htmlentities($robot_hello); ?>';
    var robot_title = '<?php echo htmlentities($robot_title); ?>';
    var customerId = '<?php echo htmlentities($customerId); ?>';
    var cusotmerName = '<?php echo htmlentities($customerName); ?>';
    var avatar = '<?php echo htmlentities($avatar); ?>';
    var os = '<?php echo htmlentities($os); ?>';
    var pre_see = <?php echo htmlentities($pre_see); ?>;
    var pre_input = <?php echo htmlentities($pre_input); ?>;
    var goback_url = '<?php echo htmlentities($referer); ?>';
    var agent = '<?php echo htmlentities($agent); ?>';
</script>
<script src="/static/common/js/jquery.min.js"></script>
<script src="/static/common/js/jqueryWeui/jquery-weui.min.js"></script>
<script src="/static/layui/layui.js"></script>
<?php if($model == 1): ?>
<script src="/static/common/js/socket.io.js"></script>
<script src="/static/common/js/ai_service.io.js"></script>
<script src="/static/customer/js/ai_service.cli.io.js"></script>
<?php else: ?>
<script src="/static/common/js/reconnecting-websocket.min.js"></script>
<script src="/static/common/js/ai_service.v2.js"></script>
<script src="/static/customer/js/ai_service.cli.v2.js"></script>
<?php endif; ?>
</body>
</html>