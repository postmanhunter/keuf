<?php /*a:1:{s:68:"/www/wwwroot/42.193.184.147/application/seller/view/index/index.html";i:1630552330;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>多商户客服后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/style/admin.css" media="all">
</head>
<body class="layui-layout-body">

<div id="LAY_app">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <!-- 头部区域 -->
            <ul class="layui-nav layui-layout-left">
                <li class="layui-nav-item layadmin-flexible" lay-unselect>
                    <a href="javascript:;" layadmin-event="flexible" title="侧边伸缩">
                        <i class="layui-icon layui-icon-shrink-right" id="LAY_app_flexible"></i>
                    </a>
                </li>
                <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="/" target="_blank" title="前台">
                        <i class="layui-icon layui-icon-website"></i>
                    </a>
                </li>
                <li class="layui-nav-item" lay-unselect>
                    <a href="javascript:;" layadmin-event="refresh" title="刷新">
                        <i class="layui-icon layui-icon-refresh-3"></i>
                    </a>
                </li>
            </ul>
            <ul class="layui-nav layui-layout-right" lay-filter="layadmin-layout-right">
                <li class="layui-nav-item" lay-unselect="">
                    <a lay-href="<?php echo url('log/leave'); ?>" layadmin-event="message" lay-text="留言列表">
                        <i class="layui-icon layui-icon-notice"></i>
                        <?php if($no_read > 0): ?>
                        <span class="layui-badge-dot"></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="javascript:;" layadmin-event="theme">
                        <i class="layui-icon layui-icon-theme"></i>
                    </a>
                </li>
                <li class="layui-nav-item layui-hide-xs" lay-unselect>
                    <a href="javascript:;" layadmin-event="fullscreen">
                        <i class="layui-icon layui-icon-screen-full"></i>
                    </a>
                </li>
                <li class="layui-nav-item" lay-unselect>
                    <a href="javascript:;">
                        <cite><?php echo htmlentities($seller_name); ?></cite>
                    </a>
                    <dl class="layui-nav-child">
                        <!--<dd><a href="javascript:;" onclick="editPwd();">修改密码</a></dd>-->
                        <hr>
                        <dd lay-href="/seller/login/loginOut" style="text-align: center;"><a>退出</a></dd>
                    </dl>
                </li>

               
            </ul>
        </div>

        <!-- 侧边菜单 -->
        <div class="layui-side layui-side-menu">
            <div class="layui-side-scroll">
                <div class="layui-logo" style="background-size: 20px 20px">
                    <span>多商户客服</span>
                </div>

                <ul class="layui-nav layui-nav-tree" lay-shrink="all" id="LAY-system-side-menu" lay-filter="layadmin-system-side-menu">
                    <li data-name="home" class="layui-nav-item layui-nav-itemed">
                        <a href="javascript:;" lay-tips="主页" lay-direction="2">
                            <i class="layui-icon layui-icon-home"></i>
                            <cite>主页</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd data-name="console" class="layui-this">
                                <a lay-href="<?php echo url('index/home'); ?>">控制台</a>
                            </dd>
                        </dl>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="/service/index/index/u/<?php echo htmlentities($seller_code); ?>" target="_blank">
                            <i class="layui-icon layui-icon-senior"></i>
                            <cite>客服工作台</cite>
                        </a>
                    </li>

                    <li data-name="template" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="分组管理" lay-direction="2">
                            <i class="layui-icon layui-icon-component"></i>
                            <cite>分组管理</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('group/index'); ?>">分组列表</a></dd>
                        </dl>
                    </li>

                    <li data-name="template" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="客服管理" lay-direction="2">
                            <i class="layui-icon layui-icon-user"></i>
                            <cite>客服管理</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('KeFu/index'); ?>">客服列表</a></dd>
                        </dl>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="系统设置" lay-direction="2">
                            <i class="layui-icon layui-icon-set"></i>
                            <cite>系统设置</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('system/index'); ?>">系统设置</a></dd>
                            <dd><a lay-href="<?php echo url('system/myStyle'); ?>">样式设置</a></dd>
                        </dl>
                    </li>

                    <li data-name="template" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="分组管理" lay-direction="2">
                            <i class="layui-icon layui-icon-component"></i>
                            <cite>机器人知识库</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('robot/index'); ?>">问答库</a></dd>
                            <dd><a lay-href="<?php echo url('robot/question'); ?>">未知问题</a></dd>
                        </dl>
                    </li>

                    <li data-name="template" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="常用语管理" lay-direction="2">
                            <i class="layui-icon layui-icon-file-b"></i>
                            <cite>常用语管理</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('words/index'); ?>">常用语列表</a></dd>
                        </dl>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('cate/index'); ?>">常用语分类管理</a></dd>
                        </dl>
                    </li>

                    <li data-name="template" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="会话管理" lay-direction="2">
                            <i class="layui-icon layui-icon-chat"></i>
                            <cite>会话管理</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('log/index'); ?>">会话管理</a></dd>
                            <dd><a lay-href="<?php echo url('log/leave'); ?>">留言列表</a></dd>
                        </dl>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="javascript:;" lay-href="<?php echo url('Question/index'); ?>" lay-tips="常见问题" lay-direction="2">
                            <i class="layui-icon layui-icon-auz"></i>
                            <cite>常见问题</cite>
                        </a>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="javascript:;" lay-tips="数据统计" lay-direction="2">
                            <i class="layui-icon layui-icon-app"></i>
                            <cite>数据统计</cite>
                        </a>
                        <dl class="layui-nav-child">
                            <dd><a lay-href="<?php echo url('KeFu/praise'); ?>">客服评价统计</a></dd>
                            <dd><a lay-href="<?php echo url('KeFu/praiseAll'); ?>">总体评价统计</a></dd>
                            <dd><a lay-href="<?php echo url('customer/index'); ?>">接待统计</a></dd>
                            <dd><a lay-href="<?php echo url('customer/area'); ?>">访客地域统计</a></dd>
                        </dl>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="javascript:;" lay-href="<?php echo url('blacklist/index'); ?>" lay-tips="黑名单管理" lay-direction="2">
                            <i class="layui-icon layui-icon-survey"></i>
                            <cite>黑名单管理</cite>
                        </a>
                    </li>

                    <li data-name="get" class="layui-nav-item">
                        <a href="javascript:;" lay-href="<?php echo url('index/howToUse'); ?>" lay-tips="如何接入" lay-direction="2">
                            <i class="layui-icon layui-icon-auz"></i>
                            <cite>如何接入</cite>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- 页面标签 -->
        <div class="layadmin-pagetabs" id="LAY_app_tabs">
            <div class="layui-icon layadmin-tabs-control layui-icon-prev" layadmin-event="leftPage"></div>
            <div class="layui-icon layadmin-tabs-control layui-icon-next" layadmin-event="rightPage"></div>
            <div class="layui-icon layadmin-tabs-control layui-icon-down">
                <ul class="layui-nav layadmin-tabs-select" lay-filter="layadmin-pagetabs-nav">
                    <li class="layui-nav-item" lay-unselect>
                        <a href="javascript:;"></a>
                        <dl class="layui-nav-child layui-anim-fadein">
                            <dd layadmin-event="closeThisTabs"><a href="javascript:;">关闭当前标签页</a></dd>
                            <dd layadmin-event="closeOtherTabs"><a href="javascript:;">关闭其它标签页</a></dd>
                            <dd layadmin-event="closeAllTabs"><a href="javascript:;">关闭全部标签页</a></dd>
                        </dl>
                    </li>
                </ul>
            </div>
            <div class="layui-tab" lay-unauto lay-allowClose="true" lay-filter="layadmin-layout-tabs">
                <ul class="layui-tab-title" id="LAY_app_tabsheader">
                    <li lay-id="<?php echo url('index/home'); ?>" lay-attr="<?php echo url('index/home'); ?>" class="layui-this"><i class="layui-icon layui-icon-home"></i></li>
                </ul>
            </div>
        </div>


        <!-- 主体内容 -->
        <div class="layui-body" id="LAY_app_body">
            <div class="layadmin-tabsbody-item layui-show">
                <iframe src="<?php echo url('index/home'); ?>" frameborder="0" class="layadmin-iframe"></iframe>
            </div>
        </div>

        <!-- 辅助元素，一般用于移动设备下遮罩 -->
        <div class="layadmin-body-shade" layadmin-event="shade"></div>
    </div>
</div>

<script src="/static/admin/layui/layui.js"></script>
<script>
    layui.config({
        base: '/static/admin/' //静态资源所在路径
    }).extend({
        index: 'lib/index' //主入口模块
    }).use('index');
    
    function editPwd() {
        layer.open({
            type: 2,
            title: '修改密码',
            shade: 0.6,
            area: ['40%', '50%'],
            content: '<?php echo url("index/editPwd"); ?>'
        });
    }
</script>

</body>
</html>