<?php

return [
    // 版本
    'version' => 'v2.1.14',
];