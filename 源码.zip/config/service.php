<?php
/**
 * Created by PhpStorm.
 * User: Cc
 * Email: ega88761@qq.com
 * Date: 2019/2/16
 * Time: 11:35 PM
 */
return [

    // 加密盐
    'salt' => '~NickBai!@#123',

    // 通信协议
    'protocol' => 'ws://',

    // socket server
    'socket' => '42.193.184.147:2020',

    // 初始化问候语
    'hello_word' => '您好，客服为您服务',

    // 当前系统域名
    'domain' => 'http://42.193.184.147',

    // 聊天信息一次展示多少条
    'log_page' => 10,

    // 是否开启商户注册
    'reg_flag' => true,

    // api接口
    'api_url' => 'http://42.193.184.147/index/test/receive'
];